package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;import com.google.firebase.auth.FirebaseAuth;import com.google.firebase.firestore.*;import java.util.*;
public class MessagesActivity extends Activity{
 ListenerRegistration reg;LinearLayout list;String uid;
 public void onCreate(Bundle b){super.onCreate(b);uid=FirebaseAuth.getInstance().getUid();LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Chats"));r.addView(Ui.body(this,"Real conversations • No demo contacts"));ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sv.addView(list);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));LinearLayout nav=Ui.nav(this,"Chats");for(int i=0;i<nav.getChildCount();i++){final int k=i;nav.getChildAt(i).setOnClickListener(v->{if(k==0)startActivity(new Intent(this,HomeActivity.class));if(k==2)startActivity(new Intent(this,VideoHubActivity.class));if(k==3)startActivity(new Intent(this,TopUpActivity.class));if(k==4)startActivity(new Intent(this,MyProfileActivity.class));});}r.addView(nav);setContentView(r);list.addView(Ui.body(this,"No real conversations yet. Find a person on Home to connect."));}
 protected void onDestroy(){if(reg!=null)reg.remove();super.onDestroy();}
}
