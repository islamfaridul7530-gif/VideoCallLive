V38 focused fixes only:
- Sync locally selected main profile photo to Firebase Storage/Firestore when cloud photoUrl is missing.
- Home cards, incoming call, and call chat continue to read the same users/{uid}.photoUrl.
- Incoming call buttons use visible DECLINE / ACCEPT labels.
- Call composer is translated above the keyboard while typing; send stays accessible.
- Call message avatars remain circular and message typography is cleaner.
- Existing working call controls were not redesigned.
