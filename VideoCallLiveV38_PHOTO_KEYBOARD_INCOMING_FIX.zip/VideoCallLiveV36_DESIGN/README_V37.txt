Video Call Live V37
Scope only:
- Keep V36 working call controls intact.
- Use Firestore users/{uid}.photoUrl for Home profile cards and incoming-call photo.
- Call chat avatars load each user photo and render circular.
- Keyboard: keep message composer/send visible by collapsing call-chat history and controls while typing.
- Incoming call: visible Accept and Decline labels/icons; caller photo loaded from profile.
- Version code 37.
