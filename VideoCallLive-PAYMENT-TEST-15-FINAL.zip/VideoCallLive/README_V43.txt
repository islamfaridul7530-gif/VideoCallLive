VideoCallLive V43
Changes only:
1. Normal chat messages show sender profile photo.
2. Normal chat messages show message time.
3. Video call keeps screen on while RealCallActivity is active.
Keyboard/composer fix from base was not modified.
Home/theme/call signaling/WebRTC quality settings were not modified.
