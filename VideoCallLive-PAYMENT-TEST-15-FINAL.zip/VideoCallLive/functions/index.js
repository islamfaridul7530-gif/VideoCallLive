const admin = require("firebase-admin");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");

admin.initializeApp();
const db = admin.firestore();
const CASHFREE_APP_ID = defineSecret("CASHFREE_APP_ID");
const CASHFREE_SECRET_KEY = defineSecret("CASHFREE_SECRET_KEY");
const BASE = "https://sandbox.cashfree.com";
const API_VERSION = "2025-01-01";
const PACKS = {
  test_15: { amount: 15, coins: 300 },
  pack_100: { amount: 100, coins: 100 },
  pack_200: { amount: 200, coins: 220 },
  pack_500: { amount: 500, coins: 600 },
  pack_1000: { amount: 1000, coins: 1300 }
};
function headers(){return {"Content-Type":"application/json","Accept":"application/json","x-api-version":API_VERSION,"x-client-id":CASHFREE_APP_ID.value(),"x-client-secret":CASHFREE_SECRET_KEY.value()};}
exports.healthCheck = onCall({region:"asia-south1"}, async()=>({ok:true,service:"VideoCallLive",paymentEnvironment:"sandbox"}));
exports.createCashfreeOrder = onCall({region:"asia-south1",secrets:[CASHFREE_APP_ID,CASHFREE_SECRET_KEY]}, async(request)=>{
 if(!request.auth) throw new HttpsError("unauthenticated","Please login first.");
 const pack=PACKS[String(request.data?.packId||"")];
 if(!pack) throw new HttpsError("invalid-argument","Invalid coin pack.");
 const phone=String(request.data?.phone||"").replace(/\D/g,"").slice(-10);
 if(phone.length!==10) throw new HttpsError("invalid-argument","Valid 10 digit phone number required.");
 const uid=request.auth.uid; const orderId="VCL_"+uid.substring(0,8)+"_"+Date.now();
 await db.collection("paymentOrders").doc(orderId).set({uid,packId:String(request.data.packId),amount:pack.amount,coins:pack.coins,status:"CREATED",environment:"sandbox",createdAt:admin.firestore.FieldValue.serverTimestamp()});
 const r=await fetch(BASE+"/pg/orders",{method:"POST",headers:headers(),body:JSON.stringify({order_id:orderId,order_amount:pack.amount,order_currency:"INR",customer_details:{customer_id:uid,customer_phone:phone},order_note:pack.coins+" Video Call Live Coins",order_tags:{uid,pack_id:String(request.data.packId),coins:String(pack.coins)}})});
 const result=await r.json();
 if(!r.ok||!result.payment_session_id){console.error("Cashfree create order",r.status,result);await db.collection("paymentOrders").doc(orderId).update({status:"CREATE_FAILED"});throw new HttpsError("internal","Unable to create payment order.");}
 await db.collection("paymentOrders").doc(orderId).update({status:"CHECKOUT_READY",paymentSessionId:result.payment_session_id,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
 return {orderId,paymentSessionId:result.payment_session_id,amount:pack.amount,coins:pack.coins};
});
exports.verifyCashfreePayment = onCall({region:"asia-south1",secrets:[CASHFREE_APP_ID,CASHFREE_SECRET_KEY]}, async(request)=>{
 if(!request.auth) throw new HttpsError("unauthenticated","Please login first.");
 const orderId=String(request.data?.orderId||"").trim(); if(!orderId) throw new HttpsError("invalid-argument","orderId is required.");
 const orderRef=db.collection("paymentOrders").doc(orderId); const snap=await orderRef.get(); if(!snap.exists) throw new HttpsError("not-found","Payment order not found.");
 const order=snap.data(); if(order.uid!==request.auth.uid) throw new HttpsError("permission-denied","This order belongs to another user.");
 if(order.status==="PAID") return {success:true,alreadyCredited:true,orderId,coins:Number(order.coins||0)};
 const r=await fetch(BASE+"/pg/orders/"+encodeURIComponent(orderId)+"/payments",{method:"GET",headers:headers()}); const payments=await r.json();
 if(!r.ok||!Array.isArray(payments)){console.error("Cashfree verify",r.status,payments);throw new HttpsError("internal","Unable to verify payment.");}
 const success=payments.find(p=>p.payment_status==="SUCCESS"); const pending=payments.find(p=>p.payment_status==="PENDING");
 if(!success) return {success:false,status:pending?"PENDING":"FAILED",orderId,coins:0};
 const userRef=db.collection("users").doc(request.auth.uid);
 await db.runTransaction(async(tx)=>{const fresh=await tx.get(orderRef);if(!fresh.exists)throw new HttpsError("not-found","Payment order not found.");const fo=fresh.data();if(fo.status==="PAID")return;const us=await tx.get(userRef);const current=Number(us.exists?(us.data().coinBalance||0):0);tx.set(userRef,{coinBalance:current+Number(fo.coins||0),updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});tx.update(orderRef,{status:"PAID",paymentId:success.cf_payment_id||null,paymentStatus:success.payment_status,paidAt:admin.firestore.FieldValue.serverTimestamp(),updatedAt:admin.firestore.FieldValue.serverTimestamp()});});
 return {success:true,alreadyCredited:false,orderId,coins:Number(order.coins||0)};
});
