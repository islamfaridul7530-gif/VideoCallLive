V39 targeted fix
- Profile photo upload now falls back to a compressed Firestore data image when Firebase Storage upload fails.
- ProfileImages can display both HTTPS Firebase images and the Firestore data-image fallback.
- Outgoing call writes caller name/photo/country in the initial call document, removing the update-before-create race.
- Incoming call reads caller data from the call document immediately and uses dp-sized ACCEPT/DECLINE buttons.
- Existing working WebRTC controls and V38 keyboard composer behavior are preserved.
