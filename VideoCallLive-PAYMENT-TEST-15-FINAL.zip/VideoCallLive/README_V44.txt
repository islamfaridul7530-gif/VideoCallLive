V44 PAYMENT TEST: ₹15 → 300 Coins added with Cashfree Sandbox checkout.

V44: Video quality tuning only. Camera capture remains 1280x720, raised from 24fps to 30fps. WebRTC video max bitrate raised from 1.8 Mbps to 3.0 Mbps, minimum bitrate from 250 kbps to 500 kbps, max framerate 30. V43 chat photo/time/keep-screen and other app behavior preserved.
