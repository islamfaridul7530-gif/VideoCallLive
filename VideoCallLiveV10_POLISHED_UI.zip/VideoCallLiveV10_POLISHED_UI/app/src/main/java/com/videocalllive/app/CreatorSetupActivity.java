package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.text.InputType;import android.widget.*;
public class CreatorSetupActivity extends Activity{
 EditText name,country,bio,rate;
 public void onCreate(Bundle b){super.onCreate(b);android.content.SharedPreferences p=getSharedPreferences("vcl",0);if(p.getBoolean("creator_profile_complete",false)){startActivity(new Intent(this,CreatorHomeActivity.class));finish();return;}
  ScrollView sv=new ScrollView(this);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Create Creator Profile"));r.addView(Ui.body(this,"Set up the profile people will see. You can choose your own video-call rate."));
  name=Ui.input(this,"Display name");country=Ui.input(this,"Country");bio=Ui.input(this,"Short bio");rate=Ui.input(this,"Coins per minute (50-500)");rate.setInputType(InputType.TYPE_CLASS_NUMBER);
  r.addView(name);r.addView(country);r.addView(bio);r.addView(rate);r.addView(Ui.body(this,"Example: 80 means callers see 80 coins/min. You can change this later."));Button save=Ui.button(this,"Save & Open Creator Home");r.addView(save);
  save.setOnClickListener(v->{String n=name.getText().toString().trim(),c=country.getText().toString().trim(),b1=bio.getText().toString().trim(),rs=rate.getText().toString().trim();if(n.isEmpty()||c.isEmpty()||rs.isEmpty()){Ui.toast(this,"Name, country aur call rate dalo");return;}int x;try{x=Integer.parseInt(rs);}catch(Exception e){Ui.toast(this,"Valid coin rate dalo");return;}if(x<50||x>500){Ui.toast(this,"Rate 50 se 500 coins/min rakho");return;}p.edit().putString("creator_name",n).putString("creator_country",c).putString("creator_bio",b1).putInt("creator_rate",x).putBoolean("creator_profile_complete",true).apply();FirebaseHelper.saveCreator(this,n,c,b1,x);startActivity(new Intent(this,CreatorHomeActivity.class));finishAffinity();});sv.addView(r);setContentView(sv);
 }
}
