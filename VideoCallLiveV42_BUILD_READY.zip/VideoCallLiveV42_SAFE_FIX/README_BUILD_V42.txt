VideoCallLive V42 build-ready source.
Build method: GitHub Actions setup-gradle (Gradle 8.9), then run `gradle clean assembleRelease` from this project directory.
This project intentionally does not depend on a Gradle Wrapper.
