Video Call Live V17
- Keeps V16 working filters/follow/profile/safety flow.
- 3 x 15-second free calls; payment/top-up prompt removed from free-call end flow.
- Call screen shows call number + countdown and uses FLAG_SECURE.
- Chat messages persist locally per demo profile with timestamps.
- Female normal profile save now also attempts Firestore save when a Firebase-authenticated UID exists.
- Phone OTP remains intentionally unchanged/side-lined.
- Real RTC video and production multi-user backend still require signaling/RTC and deployed Firebase rules/auth.
