package com.videocalllive.app;

import android.content.Context;
import org.webrtc.*;
import java.util.*;

public class WebRtcClient {
 public interface Listener { void onIce(IceCandidate c); void onConnected(); void onDisconnected(); }
 private final Context ctx; private final Listener listener; private final EglBase egl;
 private PeerConnectionFactory factory; private PeerConnection pc; private VideoCapturer capturer; private VideoSource videoSource; private AudioSource audioSource;
 private VideoTrack localVideo; private AudioTrack localAudio; private SurfaceViewRenderer localView, remoteView;
 public WebRtcClient(Context c, SurfaceViewRenderer local, SurfaceViewRenderer remote, Listener l){ctx=c;localView=local;remoteView=remote;listener=l;egl=EglBase.create();init();}
 public EglBase.Context eglContext(){return egl.getEglBaseContext();}
 private void init(){
  PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions());
  DefaultVideoEncoderFactory enc=new DefaultVideoEncoderFactory(egl.getEglBaseContext(),true,true);
  DefaultVideoDecoderFactory dec=new DefaultVideoDecoderFactory(egl.getEglBaseContext());
  factory=PeerConnectionFactory.builder().setVideoEncoderFactory(enc).setVideoDecoderFactory(dec).createPeerConnectionFactory();
  localView.init(egl.getEglBaseContext(),null);remoteView.init(egl.getEglBaseContext(),null);localView.setMirror(true);remoteView.setMirror(false);
  List<PeerConnection.IceServer> ice=new ArrayList<>();ice.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer());ice.add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer());
  pc=factory.createPeerConnection(ice,new PeerConnection.Observer(){
   public void onSignalingChange(PeerConnection.SignalingState s){} public void onIceConnectionChange(PeerConnection.IceConnectionState s){if(s==PeerConnection.IceConnectionState.CONNECTED||s==PeerConnection.IceConnectionState.COMPLETED)listener.onConnected(); if(s==PeerConnection.IceConnectionState.DISCONNECTED||s==PeerConnection.IceConnectionState.FAILED||s==PeerConnection.IceConnectionState.CLOSED)listener.onDisconnected();}
   public void onIceConnectionReceivingChange(boolean b){} public void onIceGatheringChange(PeerConnection.IceGatheringState s){} public void onIceCandidate(IceCandidate c){listener.onIce(c);} public void onIceCandidatesRemoved(IceCandidate[] c){} public void onAddStream(MediaStream s){} public void onRemoveStream(MediaStream s){} public void onDataChannel(DataChannel d){} public void onRenegotiationNeeded(){}
   public void onAddTrack(RtpReceiver r,MediaStream[] ms){MediaStreamTrack t=r.track();if(t instanceof VideoTrack)((VideoTrack)t).addSink(remoteView);}
  });
  startMedia();
 }
 private void startMedia(){
  capturer=createCamera(); if(capturer==null)return; videoSource=factory.createVideoSource(false); SurfaceTextureHelper sth=SurfaceTextureHelper.create("CaptureThread",egl.getEglBaseContext());capturer.initialize(sth,ctx,videoSource.getCapturerObserver());try{capturer.startCapture(640,480,24);}catch(Exception ignored){}
  localVideo=factory.createVideoTrack("v0",videoSource);localVideo.addSink(localView);audioSource=factory.createAudioSource(new MediaConstraints());localAudio=factory.createAudioTrack("a0",audioSource);pc.addTrack(localVideo,Collections.singletonList("stream0"));pc.addTrack(localAudio,Collections.singletonList("stream0"));
 }
 private VideoCapturer createCamera(){Camera2Enumerator e=new Camera2Enumerator(ctx);for(String d:e.getDeviceNames())if(e.isFrontFacing(d)){VideoCapturer v=e.createCapturer(d,null);if(v!=null)return v;}for(String d:e.getDeviceNames()){VideoCapturer v=e.createCapturer(d,null);if(v!=null)return v;}return null;}
 public void offer(final SdpObserver out){pc.createOffer(new SdpObserver(){public void onCreateSuccess(SessionDescription s){pc.setLocalDescription(new SimpleSdp(),s);out.onCreateSuccess(s);}public void onSetSuccess(){}public void onCreateFailure(String e){out.onCreateFailure(e);}public void onSetFailure(String e){}},new MediaConstraints());}
 public void answer(final SdpObserver out){pc.createAnswer(new SdpObserver(){public void onCreateSuccess(SessionDescription s){pc.setLocalDescription(new SimpleSdp(),s);out.onCreateSuccess(s);}public void onSetSuccess(){}public void onCreateFailure(String e){out.onCreateFailure(e);}public void onSetFailure(String e){}},new MediaConstraints());}
 public void remote(String type,String sdp){pc.setRemoteDescription(new SimpleSdp(),new SessionDescription("offer".equals(type)?SessionDescription.Type.OFFER:SessionDescription.Type.ANSWER,sdp));}
 public void ice(String mid,int index,String sdp){pc.addIceCandidate(new IceCandidate(mid,index,sdp));}
 public void mute(boolean m){if(localAudio!=null)localAudio.setEnabled(!m);} public void camera(boolean on){if(localVideo!=null)localVideo.setEnabled(on);} public void flip(){if(capturer instanceof CameraVideoCapturer)((CameraVideoCapturer)capturer).switchCamera(null);}
 public void close(){try{if(capturer!=null)capturer.stopCapture();}catch(Exception ignored){}if(capturer!=null)capturer.dispose();if(pc!=null)pc.close();if(videoSource!=null)videoSource.dispose();if(audioSource!=null)audioSource.dispose();if(factory!=null)factory.dispose();localView.release();remoteView.release();egl.release();}
 static class SimpleSdp implements SdpObserver{public void onCreateSuccess(SessionDescription s){}public void onSetSuccess(){}public void onCreateFailure(String e){}public void onSetFailure(String e){}}
}
