package com.videocalllive.app;
import android.app.Activity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
public class FirebaseHelper {
 public static boolean ready(Activity a){try{if(FirebaseApp.getApps(a).isEmpty()) FirebaseApp.initializeApp(a);return !FirebaseApp.getApps(a).isEmpty();}catch(Exception e){return false;}}
 public static void saveProfile(Activity a,String gender){
  if(!ready(a))return; try{String uid=FirebaseAuth.getInstance().getUid();if(uid==null)return;HashMap<String,Object> m=new HashMap<>();m.put("gender",gender);m.put("freeCallsLeft",3);m.put("updatedAt",System.currentTimeMillis());FirebaseFirestore.getInstance().collection("users").document(uid).set(m, SetOptions.merge());}catch(Exception ignored){}
 }
 public static void saveCreator(Activity a,String name,String country,String bio,int rate){
  if(!ready(a))return; try{String uid=FirebaseAuth.getInstance().getUid();if(uid==null)return;HashMap<String,Object> m=new HashMap<>();m.put("gender","female");m.put("creatorName",name);m.put("country",country);m.put("bio",bio);m.put("callRateCoinsPerMinute",rate);m.put("creatorProfileComplete",true);m.put("online",true);m.put("updatedAt",System.currentTimeMillis());FirebaseFirestore.getInstance().collection("users").document(uid).set(m, SetOptions.merge());}catch(Exception ignored){}
 }
 public static void savePublicProfile(Activity a,String name,int age,String country,String bio){
  if(!ready(a))return; try{String uid=FirebaseAuth.getInstance().getUid();if(uid==null)return;HashMap<String,Object> m=new HashMap<>();m.put("displayName",name);m.put("age",age);m.put("country",country);m.put("bio",bio);m.put("profileComplete",true);m.put("online",true);m.put("updatedAt",System.currentTimeMillis());FirebaseFirestore.getInstance().collection("users").document(uid).set(m, SetOptions.merge());}catch(Exception ignored){}
 }

 public static void restoreProfile(Activity a){
  if(!ready(a) || FirebaseAuth.getInstance().getCurrentUser()==null)return;
  String uid=FirebaseAuth.getInstance().getUid();
  FirebaseFirestore.getInstance().collection("users").document(uid).get()
   .addOnSuccessListener(doc->{
    if(a.isFinishing())return;
    if(doc.exists() && ("male".equals(doc.getString("gender")) || "female".equals(doc.getString("gender")))){
     android.content.SharedPreferences.Editor e=a.getSharedPreferences("vcl",0).edit();
     e.putString("account_uid",uid).putString("gender",doc.getString("gender"));
     if(doc.getString("displayName")!=null)e.putString("profile_name",doc.getString("displayName"));
     if(doc.getString("country")!=null)e.putString("profile_country",doc.getString("country"));
     if(doc.getString("bio")!=null)e.putString("profile_bio",doc.getString("bio"));
     if(doc.getLong("age")!=null)e.putInt("profile_age",doc.getLong("age").intValue());
     if(doc.getLong("freeCallsLeft")!=null)e.putInt("free_calls_left",doc.getLong("freeCallsLeft").intValue());
     e.apply();a.startActivity(new android.content.Intent(a,HomeActivity.class));
    }else{a.getSharedPreferences("vcl",0).edit().putString("account_uid",uid).remove("gender").apply();a.startActivity(new android.content.Intent(a,GenderActivity.class));}
    a.finish();
   }).addOnFailureListener(err->{android.widget.Toast.makeText(a,"Profile could not load. Check internet and retry.",android.widget.Toast.LENGTH_LONG).show();});
 }
}
