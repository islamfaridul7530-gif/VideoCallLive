VIDEO CALL LIVE V20 — REAL VIDEO CALL TEST BUILD

What is new
- Keeps the V19 project and Firebase phone OTP setup.
- Uses the latest google-services.json from the repository snapshot supplied by the user.
- Adds WebRTC Android SDK for real camera/microphone peer-to-peer media.
- Uses Cloud Firestore as call signaling (offer, answer and ICE candidates).
- Adds Real Users screen. It reads real Firebase user documents and filters out the current user / same gender.
- Adds incoming call Accept / Decline while the receiver has the Real Users screen open.
- Adds real call controls: mute, camera on/off, flip camera and end.
- Existing V19 demo flow remains available.

First test requirements
1. Firebase Authentication and Firestore must be enabled for the project.
2. Both phones must use this V20 build, log in with different accounts, select genders, and create/save profiles.
3. Keep Real Users screen open on receiver phone for this first test build.
4. Caller opens Video Calls > REAL VIDEO CALL V20 and taps the receiver.
5. Receiver accepts. Grant Camera and Microphone permissions on both phones.

Important production note
- This first real RTC build uses public Google STUN servers. For reliable calls across all mobile/Wi-Fi networks, a TURN server must be configured before production.
- Background incoming-call notifications require FCM / a foreground call service and are not yet included in this first V20 test build.
- Free-trial/payment enforcement is not yet wired to real RTC. First verify real two-phone audio/video, then connect the 3x15 second rule and billing.
