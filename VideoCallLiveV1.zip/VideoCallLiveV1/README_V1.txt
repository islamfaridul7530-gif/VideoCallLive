VIDEO CALL LIVE — V1

Included:
- Quick Login
- Login UI
- Male/Female select
- Discover profiles
- Profile details
- Follow
- Message screen
- Video call screen
- 3 free male calls x 30 seconds
- Top Up to Continue popup
- Top Up screen
- Home / Messages / Top Up / Profile navigation
- FLAG_SECURE on call screen to block normal screenshots/screen recording
- Camera, microphone and internet permissions
- Native Android project for APK/AAB builds

Not yet connected in V1:
- Real two-phone WebRTC video/audio
- Backend/signaling
- Real message sync
- Real Google Play Billing
