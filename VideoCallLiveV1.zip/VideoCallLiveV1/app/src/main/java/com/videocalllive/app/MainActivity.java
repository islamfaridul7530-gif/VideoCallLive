package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Video Call Live"));r.addView(Ui.body(this,"Meet people, chat and start live video calls."));
 Button q=Ui.button(this,"Quick Login"),l=Ui.secondary(this,"Login");r.addView(q);r.addView(l);
 q.setOnClickListener(v->{getSharedPreferences("vcl",0).edit().putBoolean("quick",true).apply();startActivity(new Intent(this,GenderActivity.class));});
 l.setOnClickListener(v->startActivity(new Intent(this,LoginActivity.class)));setContentView(r);}
}
