package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class LoginActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Login"));EditText n=Ui.input(this,"Name"),e=Ui.input(this,"Email or phone"),p=Ui.input(this,"Password");p.setInputType(129);r.addView(n);r.addView(e);r.addView(p);Button c=Ui.button(this,"Continue");r.addView(c);c.setOnClickListener(v->{getSharedPreferences("vcl",0).edit().putString("name",n.getText().toString()).putBoolean("quick",false).apply();startActivity(new Intent(this,GenderActivity.class));});setContentView(r);}
}
