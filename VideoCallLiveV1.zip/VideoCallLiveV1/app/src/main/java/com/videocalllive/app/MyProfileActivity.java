package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class MyProfileActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);android.content.SharedPreferences p=getSharedPreferences("vcl",0);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"My Profile"));r.addView(Ui.body(this,"Name: "+p.getString("name",p.getBoolean("quick",false)?"Quick User":"User")+"\nGender: "+p.getString("gender","")+"\nFree calls left: "+p.getInt("free_calls_left",3)+"\n\nCall screen blocks normal screenshots and screen recording."));Button l=Ui.secondary(this,"Log out");r.addView(l);l.setOnClickListener(v->{p.edit().clear().apply();startActivity(new Intent(this,MainActivity.class));finishAffinity();});setContentView(r);}
}
