package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.text.InputType;import android.view.View;import android.widget.*;
import com.google.firebase.FirebaseException;import com.google.firebase.auth.*;import java.io.*;import java.util.concurrent.TimeUnit;

public class LoginActivity extends Activity {
 EditText phone,otp; Button send,verify; String verificationId;
 public void onCreate(Bundle b){super.onCreate(b);try{
  LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Phone Login"));
  r.addView(Ui.body(this,"V6 OTP Fix\nEnter number with country code, for example +91XXXXXXXXXX"));
  phone=Ui.input(this,"+91 Phone number");phone.setInputType(InputType.TYPE_CLASS_PHONE);r.addView(phone);
  send=Ui.button(this,"Send OTP");r.addView(send);
  otp=Ui.input(this,"6-digit OTP");otp.setInputType(InputType.TYPE_CLASS_NUMBER);otp.setVisibility(View.GONE);r.addView(otp);
  verify=Ui.button(this,"Verify OTP");verify.setVisibility(View.GONE);r.addView(verify);
  send.setOnClickListener(v->sendOtp());verify.setOnClickListener(v->verifyOtp());setContentView(r);
 }catch(Throwable e){showError("Login screen startup",e);}}

 void stage(String s){getSharedPreferences("vcl_crash",0).edit().putString("last_stage",s).commit();}

 void sendOtp(){
  stage("1 Send OTP tapped");
  try{
   if(!FirebaseHelper.ready(this)){showText("Firebase Error","Firebase is not initialized/configured.");return;}
   stage("2 Firebase ready");
   String p=phone.getText().toString().trim();
   if(!p.startsWith("+")||p.length()<10){Ui.toast(this,"Country code ke saath phone number dalo");return;}
   stage("3 Number validated");
   FirebaseAuth auth=FirebaseAuth.getInstance(); stage("4 FirebaseAuth ready");
   PhoneAuthProvider.OnVerificationStateChangedCallbacks cb=new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
    public void onVerificationCompleted(PhoneAuthCredential c){stage("8 Verification completed");try{sign(c);}catch(Throwable e){showError("onVerificationCompleted",e);}}
    public void onVerificationFailed(FirebaseException e){stage("7 Verification failed");showError("Firebase OTP rejected",e);}
    public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken t){stage("7 OTP code sent");try{verificationId=id;otp.setVisibility(View.VISIBLE);verify.setVisibility(View.VISIBLE);showText("OTP Sent","Firebase accepted the OTP request.");}catch(Throwable e){showError("onCodeSent",e);}}
    public void onCodeAutoRetrievalTimeOut(String id){stage("9 OTP timeout");verificationId=id;}
   };
   stage("5 Callbacks ready");
   PhoneAuthOptions o=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(p).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(cb).build();
   stage("6 Before verifyPhoneNumber");
   PhoneAuthProvider.verifyPhoneNumber(o);
   stage("6B verifyPhoneNumber returned");
  }catch(Throwable e){showError("Send OTP error",e);}
 }

 void verifyOtp(){try{String c=otp.getText().toString().trim();if(verificationId==null||c.length()<6){Ui.toast(this,"6-digit OTP dalo");return;}sign(PhoneAuthProvider.getCredential(verificationId,c));}catch(Throwable e){showError("Verify OTP",e);}}

 void sign(PhoneAuthCredential c){FirebaseAuth.getInstance().signInWithCredential(c)
  .addOnSuccessListener(x->{getSharedPreferences("vcl",0).edit().putBoolean("quick",false).putString("name",phone.getText().toString()).apply();startActivity(new Intent(this,GenderActivity.class));finish();})
  .addOnFailureListener(e->showError("Firebase sign-in failed",e));}

 void showError(String where,Throwable e){
  StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));
  String d=where+"\n\n"+sw;
  getSharedPreferences("vcl_crash",0).edit().putString("last_otp_error",d).putString("last_stage",where).commit();
  try{new AlertDialog.Builder(this).setTitle("OTP Diagnostic Error").setMessage(where+"\n\n"+(e.getMessage()==null?e.getClass().getName():e.getMessage())+"\n\nIska screenshot bhejo.").setPositiveButton("OK",null).show();}catch(Throwable ignored){}
 }
 void showText(String t,String m){try{new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}catch(Throwable e){Ui.toast(this,m);}}
}
