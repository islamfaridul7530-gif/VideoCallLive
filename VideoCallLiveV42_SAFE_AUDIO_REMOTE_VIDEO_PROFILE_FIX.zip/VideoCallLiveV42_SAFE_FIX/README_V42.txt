Video Call Live V42 SAFE FIX
Base: V40 (working audio preserved)

Changes intentionally limited:
1. WebRTC audio/media creation and call audio routing remain from V40.
2. Remote video: added onAddStream video-track sink fallback while retaining existing onAddTrack sink.
3. Home: V41 full-photo overlay card design retained.
4. Public profile: reads photoData first, then photoUrl, with large hero photo.
5. My Profile: larger 330dp hero image using CENTER_CROP so the photo fills the available width without black side bars.
6. Existing Mute / Video Off / Flip / Speaker / End Call behavior was not rewritten.

Test on two phones before treating remote video as confirmed fixed.
