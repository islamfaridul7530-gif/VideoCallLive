package com.videocalllive.app;
import android.app.Activity;import android.content.SharedPreferences;import android.graphics.*;import android.net.Uri;import android.util.Base64;import java.io.*;import java.util.*;import com.google.firebase.auth.FirebaseAuth;import com.google.firebase.firestore.*;import com.google.firebase.storage.FirebaseStorage;
public class ProfilePhotoSync{
 public static void ensure(Activity a){
  String uid=FirebaseAuth.getInstance().getUid();if(uid==null)return;
  SharedPreferences p=a.getSharedPreferences("vcl",0);String all=p.getString("profile_photos","");if(all==null||all.trim().isEmpty())return;
  String local=all.split("\\|\\|",2)[0];if(local.isEmpty())return;Uri uri=Uri.parse(local);FirebaseFirestore db=FirebaseFirestore.getInstance();
  // Always publish a compact Firestore copy. This avoids Storage/rules/download URL failures on other phones.
  try{Bitmap b=BitmapFactory.decodeStream(a.getContentResolver().openInputStream(uri));if(b!=null){int max=240;float sc=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));if(sc<1f)b=Bitmap.createScaledBitmap(b,Math.max(1,(int)(b.getWidth()*sc)),Math.max(1,(int)(b.getHeight()*sc)),true);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,48,out);String data="data:image/jpeg;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);Map<String,Object> m=new HashMap<>();m.put("photoData",data);m.put("updatedAt",System.currentTimeMillis());db.collection("users").document(uid).set(m,SetOptions.merge());}}catch(Exception ignored){}
  // Keep Storage URL too when Storage is available.
  try{FirebaseStorage.getInstance().getReference().child("profilePhotos/"+uid+"/main.jpg").putFile(uri).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return FirebaseStorage.getInstance().getReference().child("profilePhotos/"+uid+"/main.jpg").getDownloadUrl();}).addOnSuccessListener(url->{Map<String,Object> m=new HashMap<>();m.put("photoUrl",url.toString());m.put("updatedAt",System.currentTimeMillis());db.collection("users").document(uid).set(m,SetOptions.merge());});}catch(Exception ignored){}
 }
}
