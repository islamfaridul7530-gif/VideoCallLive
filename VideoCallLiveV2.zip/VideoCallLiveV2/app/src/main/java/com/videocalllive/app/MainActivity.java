package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Video Call Live"));r.addView(Ui.body(this,"V2 • Firebase login ready\nMeet people, chat and start live video calls."));
 Button q=Ui.button(this,"Quick Login"),l=Ui.secondary(this,"Login with Phone Number");r.addView(q);r.addView(l);
 q.setOnClickListener(v->{if(!FirebaseHelper.ready(this)){Ui.toast(this,"Firebase config missing: add google-services.json");return;}FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(x->{getSharedPreferences("vcl",0).edit().putBoolean("quick",true).apply();startActivity(new Intent(this,GenderActivity.class));}).addOnFailureListener(e->Ui.toast(this,"Quick Login failed: "+e.getMessage()));});
 l.setOnClickListener(v->startActivity(new Intent(this,LoginActivity.class)));setContentView(r);}
}
