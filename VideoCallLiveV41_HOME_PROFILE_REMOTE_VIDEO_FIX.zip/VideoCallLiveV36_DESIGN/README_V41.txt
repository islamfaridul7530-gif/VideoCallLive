V41 targeted update based on V40
- Home real profile cards: photo fills card, bottom overlay for status/name/country/age, compact round call button, tighter spacing.
- Meet New People area gets reduced horizontal page margin; tabs/navigation preserved.
- Public profile reads photoData first (same path proven working on Home/Incoming) and shows a larger real hero photo.
- My Profile main photo area increased to 330dp and CENTER_INSIDE to reduce top/bottom cropping. Existing profile options preserved.
- WebRTC remote renderer strengthened: hardware scaler + aspect fill + onAddStream fallback in addition to existing onAddTrack.
- Existing V40 incoming caller photo/name/country, Accept/Decline, chat composer/keyboard behavior and call controls preserved.
