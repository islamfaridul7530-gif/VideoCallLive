package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class HomeActivity extends Activity{
 String[] n={"Aisha","Maya","Sara","Nisha","Riya","Anaya"},c={"India","Nepal","Bangladesh","Sri Lanka","India","UAE"};
 public void onCreate(Bundle b){super.onCreate(b);draw();}
 void draw(){LinearLayout o=Ui.root(this);o.addView(Ui.title(this,"Discover"));String g=getSharedPreferences("vcl",0).getString("gender","male");int left=getSharedPreferences("vcl",0).getInt("free_calls_left",3);o.addView(Ui.body(this,g.equals("male")?"Free 30-sec calls left: "+left:"Video calls are free for eligible female users"));
 ScrollView sv=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
 for(int i=0;i<n.length;i++){final int x=i;LinearLayout card=Ui.card(this);TextView t=Ui.title(this,n[i]+" • Online");t.setTextSize(20);card.addView(t);card.addView(Ui.body(this,"Country: "+c[i]+"\nTap to view profile"));card.setOnClickListener(v->{Intent in=new Intent(this,ProfileDetailActivity.class);in.putExtra("name",n[x]);in.putExtra("country",c[x]);startActivity(in);});list.addView(card);}sv.addView(list);o.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
 LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);String[] ls={"Home","Messages","Top Up","Profile"};for(String s:ls){Button b=Ui.secondary(this,s);b.setLayoutParams(new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));nav.addView(b);b.setOnClickListener(v->{String x=((Button)v).getText().toString();if(x.equals("Messages"))startActivity(new Intent(this,MessagesActivity.class));else if(x.equals("Top Up"))startActivity(new Intent(this,TopUpActivity.class));else if(x.equals("Profile"))startActivity(new Intent(this,MyProfileActivity.class));});}o.addView(nav);setContentView(o);}
 protected void onResume(){super.onResume();draw();}
}
