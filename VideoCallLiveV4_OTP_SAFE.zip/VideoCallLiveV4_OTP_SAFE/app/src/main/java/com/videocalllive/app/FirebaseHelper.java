package com.videocalllive.app;
import android.app.Activity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
public class FirebaseHelper {
 public static boolean ready(Activity a){try{if(FirebaseApp.getApps(a).isEmpty()) FirebaseApp.initializeApp(a);return !FirebaseApp.getApps(a).isEmpty();}catch(Exception e){return false;}}
 public static void saveProfile(Activity a,String gender){
  if(!ready(a))return; try{String uid=FirebaseAuth.getInstance().getUid();if(uid==null)return;HashMap<String,Object> m=new HashMap<>();m.put("gender",gender);m.put("freeCallsLeft",3);m.put("updatedAt",System.currentTimeMillis());FirebaseFirestore.getInstance().collection("users").document(uid).set(m);}catch(Exception ignored){}
 }
}
