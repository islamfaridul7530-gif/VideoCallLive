package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class ProfileDetailActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);String n=getIntent().getStringExtra("name"),c=getIntent().getStringExtra("country");LinearLayout r=Ui.root(this);r.addView(Ui.title(this,n));r.addView(Ui.body(this,"[ Photo 1 ]   [ Photo 2 ]   [ Photo 3 ]\n\nCountry: "+c+"\nStatus: Online\nBio: Here to meet new people and chat."));Button f=Ui.secondary(this,"Follow"),m=Ui.secondary(this,"Message"),call=Ui.button(this,"Video Call");r.addView(f);r.addView(m);r.addView(call);f.setOnClickListener(v->{f.setText("Following");f.setEnabled(false);});m.setOnClickListener(v->startActivity(new Intent(this,MessagesActivity.class).putExtra("name",n)));call.setOnClickListener(v->startActivity(new Intent(this,CallActivity.class).putExtra("name",n)));setContentView(r);}
}
