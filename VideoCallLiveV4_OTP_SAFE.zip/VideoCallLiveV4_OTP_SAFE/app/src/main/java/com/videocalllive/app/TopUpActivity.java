package com.videocalllive.app;
import android.app.*;import android.os.*;import android.widget.*;
public class TopUpActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Top Up"));r.addView(Ui.body(this,"Payment UI for V1. Google Play Billing will be connected before release."));for(String s:new String[]{"₹100 • 100 Coins","₹200 • 220 Coins","₹500 • 600 Coins"}){Button x=Ui.button(this,s);r.addView(x);x.setOnClickListener(v->Ui.toast(this,"Payment not enabled in V1 test build"));}setContentView(r);}
}
