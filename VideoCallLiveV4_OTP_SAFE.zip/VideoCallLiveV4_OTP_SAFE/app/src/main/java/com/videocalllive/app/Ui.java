package com.videocalllive.app;
import android.app.*;import android.graphics.*;import android.graphics.drawable.*;import android.widget.*;
public class Ui{
 public static int dp(Activity a,int v){return (int)(v*a.getResources().getDisplayMetrics().density+.5f);}
 public static LinearLayout root(Activity a){LinearLayout r=new LinearLayout(a);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(a,20),dp(a,20),dp(a,20),dp(a,20));r.setBackgroundColor(Color.rgb(244,247,251));return r;}
 public static TextView title(Activity a,String s){TextView t=new TextView(a);t.setText(s);t.setTextSize(28);t.setTextColor(Color.rgb(17,17,17));t.setTypeface(Typeface.DEFAULT,1);t.setPadding(0,dp(a,10),0,dp(a,12));return t;}
 public static TextView body(Activity a,String s){TextView t=new TextView(a);t.setText(s);t.setTextSize(16);t.setTextColor(Color.rgb(80,85,95));t.setPadding(0,dp(a,4),0,dp(a,8));return t;}
 public static Button button(Activity a,String s){Button b=new Button(a);b.setText(s);b.setAllCaps(false);b.setTextSize(17);b.setTextColor(Color.WHITE);GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(23,105,224));g.setCornerRadius(dp(a,16));b.setBackground(g);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(a,56));p.setMargins(0,dp(a,8),0,dp(a,8));b.setLayoutParams(p);return b;}
 public static Button secondary(Activity a,String s){Button b=button(a,s);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setStroke(dp(a,1),Color.rgb(210,215,225));g.setCornerRadius(dp(a,16));b.setBackground(g);b.setTextColor(Color.rgb(23,105,224));return b;}
 public static EditText input(Activity a,String h){EditText e=new EditText(a);e.setHint(h);e.setSingleLine(true);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setStroke(dp(a,1),Color.rgb(215,220,230));g.setCornerRadius(dp(a,14));e.setBackground(g);e.setPadding(dp(a,16),0,dp(a,16),0);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(a,54));p.setMargins(0,dp(a,6),0,dp(a,8));e.setLayoutParams(p);return e;}
 public static LinearLayout card(Activity a){LinearLayout c=new LinearLayout(a);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(a,16),dp(a,16),dp(a,16),dp(a,16));GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(dp(a,18));c.setBackground(g);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(a,8),0,dp(a,8));c.setLayoutParams(p);return c;}
 public static void toast(Activity a,String s){Toast.makeText(a,s,Toast.LENGTH_SHORT).show();}
}
