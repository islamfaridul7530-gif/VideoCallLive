package com.videocalllive.app;
import android.app.*;import android.os.*;import android.widget.*;
public class MessagesActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Messages"));r.addView(Ui.body(this,"V1 message screen ready. Real sync will connect to backend later."));EditText e=Ui.input(this,"Write a message");r.addView(e);Button s=Ui.button(this,"Send");r.addView(s);s.setOnClickListener(v->{Ui.toast(this,"Message UI tested");e.setText("");});setContentView(r);}
}
