package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.text.InputType;import android.widget.*;
import com.google.firebase.FirebaseException;import com.google.firebase.auth.*;import java.util.concurrent.TimeUnit;
public class LoginActivity extends Activity{
 EditText phone,otp;Button send,verify;String verificationId;
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Phone Login"));r.addView(Ui.body(this,"Enter number with country code, for example +91XXXXXXXXXX"));phone=Ui.input(this,"+91 Phone number");phone.setInputType(InputType.TYPE_CLASS_PHONE);r.addView(phone);send=Ui.button(this,"Send OTP");r.addView(send);otp=Ui.input(this,"6-digit OTP");otp.setInputType(InputType.TYPE_CLASS_NUMBER);otp.setVisibility(android.view.View.GONE);r.addView(otp);verify=Ui.button(this,"Verify OTP");verify.setVisibility(android.view.View.GONE);r.addView(verify);send.setOnClickListener(v->sendOtp());verify.setOnClickListener(v->verifyOtp());setContentView(r);}
 void sendOtp(){if(!FirebaseHelper.ready(this)){Ui.toast(this,"Firebase config missing: add google-services.json");return;}String p=phone.getText().toString().trim();if(!p.startsWith("+")||p.length()<10){Ui.toast(this,"Country code ke saath phone number dalo");return;}PhoneAuthOptions o=PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance()).setPhoneNumber(p).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){public void onVerificationCompleted(PhoneAuthCredential c){sign(c);}public void onVerificationFailed(FirebaseException e){Ui.toast(LoginActivity.this,"OTP failed: "+e.getMessage());}public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken t){verificationId=id;otp.setVisibility(android.view.View.VISIBLE);verify.setVisibility(android.view.View.VISIBLE);Ui.toast(LoginActivity.this,"OTP sent");}}).build();try {
  PhoneAuthProvider.verifyPhoneNumber(o);
 } catch (Throwable e) {
  showOtpError(e);
 }
 }
 void showOtpError(Throwable e){
  java.io.StringWriter sw=new java.io.StringWriter();
  e.printStackTrace(new java.io.PrintWriter(sw));
  String detail=sw.toString();
  getSharedPreferences("vcl_crash",0).edit().putString("last_otp_error",detail).apply();
  new android.app.AlertDialog.Builder(this)
   .setTitle("OTP Error")
   .setMessage((e.getMessage()==null?e.getClass().getName():e.getMessage())+"\n\nApp ko crash hone se roka gaya. Is error ka screenshot bhejo.")
   .setPositiveButton("OK",null).show();
 }
 void verifyOtp(){String c=otp.getText().toString().trim();if(verificationId==null||c.length()<6){Ui.toast(this,"6-digit OTP dalo");return;}sign(PhoneAuthProvider.getCredential(verificationId,c));}
 void sign(PhoneAuthCredential c){FirebaseAuth.getInstance().signInWithCredential(c).addOnSuccessListener(x->{getSharedPreferences("vcl",0).edit().putBoolean("quick",false).putString("name",phone.getText().toString()).apply();startActivity(new Intent(this,GenderActivity.class));finish();}).addOnFailureListener(e->Ui.toast(this,"Login failed: "+e.getMessage()));}
}
