package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;import com.google.firebase.auth.FirebaseAuth;
public class MyProfileActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);draw();}
 void draw(){
  android.content.SharedPreferences p=getSharedPreferences("vcl",0);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"My Profile"));
  boolean creator="female".equals(p.getString("gender","")) && p.getBoolean("creator_profile_complete",false);
  String creatorName=p.getString("creator_name","Creator");String country=p.getString("creator_country","");String bio=p.getString("creator_bio","");int rate=p.getInt("creator_rate",80);
  TextView av=Ui.avatar(this,creator?creatorName:"Y");av.setText(creator?(creatorName.isEmpty()?"C":creatorName.substring(0,1).toUpperCase()):"YOU");av.setTextSize(28);av.setLayoutParams(new LinearLayout.LayoutParams(-1,Ui.dp(this,130)));r.addView(av);
  r.addView(Ui.title(this,creator?creatorName:"Your Profile"));
  if(creator){String details="Creator • Online"+(country.isEmpty()?"":"\n🇮🇳 "+country)+(bio.isEmpty()?"":"\n"+bio)+"\n🎥 "+rate+" coins/min";r.addView(Ui.body(this,details));}
  else r.addView(Ui.body(this,(p.getBoolean("quick",false)?"Quick Login":"Phone Login")+"  •  "+p.getString("gender","User")));
  Button edit=Ui.secondary(this,"✎ Edit Profile   ›");r.addView(edit);edit.setOnClickListener(v->{if(creator){p.edit().putBoolean("creator_profile_complete",false).apply();startActivity(new Intent(this,CreatorSetupActivity.class));finish();}else Ui.toast(this,"Edit Profile ready for next version");});
  String[] opts={"▣ My Photos","♡ Following","🔔 Notifications","🛡 Privacy & Safety","🚫 Blocked Users","? Help & Support","⚙ Settings"};for(String s:opts){Button x=Ui.secondary(this,s+"   ›");r.addView(x);x.setOnClickListener(v->Ui.toast(this,((Button)v).getText()+" ready for next version"));}
  if(creator){Button ch=Ui.secondary(this,"🎥 Creator Home   ›");r.addView(ch);ch.setOnClickListener(v->startActivity(new Intent(this,CreatorHomeActivity.class)));}
  Button l=Ui.secondary(this,"Log out");r.addView(l);l.setOnClickListener(v->{try{FirebaseAuth.getInstance().signOut();}catch(Exception ignored){}p.edit().clear().apply();startActivity(new Intent(this,MainActivity.class));finishAffinity();});
  LinearLayout nav=Ui.nav(this,"Profile");for(int i=0;i<nav.getChildCount();i++){final int k=i;nav.getChildAt(i).setOnClickListener(v->{if(k==0)startActivity(new Intent(this,HomeActivity.class));if(k==1)startActivity(new Intent(this,MessagesActivity.class));if(k==2)startActivity(new Intent(this,VideoHubActivity.class));if(k==3)startActivity(new Intent(this,TopUpActivity.class));});}r.addView(nav);setContentView(r);
 }
}
