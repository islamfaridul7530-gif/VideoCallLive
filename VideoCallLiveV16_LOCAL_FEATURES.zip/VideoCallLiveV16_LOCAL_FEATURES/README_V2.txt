Video Call Live V2
Package: com.videocalllive.app

V2 changes:
- Firebase Anonymous Authentication wired to Quick Login.
- Firebase Phone Authentication OTP screen wired to Login.
- Firestore user profile save scaffold after gender selection.
- Existing Discover, profile, messages, top-up demo, 3 x 30-sec free-call logic retained.
- CallActivity still uses FLAG_SECURE to block normal screenshots/screen recording.

IMPORTANT BEFORE REAL FIREBASE LOGIN:
Place the real Firebase Console file at:
  app/google-services.json
The file is intentionally not fabricated. Without the real config, the app builds but V2 login shows a config-missing message.

Phone Auth may also require the correct SHA certificate fingerprint in Firebase for the APK signing key used to install the app.
Real peer-to-peer video/WebRTC/signaling is NOT implemented in this V2; CallActivity remains a protected call-screen scaffold.
