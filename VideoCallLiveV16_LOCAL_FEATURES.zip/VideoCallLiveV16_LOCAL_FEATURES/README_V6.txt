Video Call Live V6 OTP Fix

Exact V5 crash:
java.lang.NoSuchMethodError for androidx.core.content.ContextCompat.registerReceiver(Context, BroadcastReceiver, IntentFilter, int)
called by firebase-auth 23.2.0.

Fix:
Explicitly add androidx.core:core:1.15.0 so Firebase Auth receives a ContextCompat version
that contains the required registerReceiver overload.

V5 diagnostics are retained so any remaining OTP error can still be shown/captured.
