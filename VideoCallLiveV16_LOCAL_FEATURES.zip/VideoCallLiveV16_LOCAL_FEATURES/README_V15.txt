Video Call Live V15
- Home header (Video Call Live + coin balance) stays fixed.
- Meet New People banner, tabs and profile cards scroll together.
- Bottom navigation stays fixed.
- Saved Photo 1 becomes the main photo on My Profile.
- Additional saved photos appear as a horizontal photo strip.
- Save Photos button is pink only when there are unsaved changes; after save it becomes dark and says Saved ✓.
- Back arrows added to profile sub-pages.
- Existing V14 hero artwork retained in this source package; it can be replaced with a licensed/owned real adult model image later without changing the profile/scroll logic.
