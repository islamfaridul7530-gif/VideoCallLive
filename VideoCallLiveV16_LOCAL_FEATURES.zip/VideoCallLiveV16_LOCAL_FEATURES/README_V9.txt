Video Call Live V9 FULL UI
- Keeps V8 Firebase/Quick Login flow
- Dark pink Home UI inspired by approved mockup
- Home profile grid and profile details
- Working local chat UI with send button
- Video hub and call screen navigation
- Coin packages/offers UI
- Profile/settings menu UI
- Bottom navigation: Home / Chats / Video / Coins / Profile
Note: Real cross-device chat, real WebRTC video and real payments still require backend/services. Phone OTP billing issue intentionally unchanged.
