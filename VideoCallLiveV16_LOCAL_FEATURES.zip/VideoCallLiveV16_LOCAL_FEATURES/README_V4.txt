Video Call Live V4 OTP Safe
- Bundled Firebase google-services.json
- Catches synchronous PhoneAuth OTP errors instead of allowing app crash
- Shows OTP Error dialog for diagnosis
- versionCode 4
