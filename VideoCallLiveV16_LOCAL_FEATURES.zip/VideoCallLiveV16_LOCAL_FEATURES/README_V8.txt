Video Call Live V8 - Session + Creator Flow

Changes from V7:
1. Existing Firebase login is reused after app is removed from Recent Apps.
2. Logged-in male -> Home; logged-in female -> Creator Home; no gender -> Gender selection.
3. Female selection opens separate Creator Profile setup.
4. Creator chooses own video-call rate from 50-500 coins/min.
5. Creator profile/rate saved locally and to Firestore.
6. V7 Firebase OTP and AndroidX Core 1.15.0 fix retained.

Still demo/not implemented: real WebRTC calls, real coin billing, creator payouts, media uploads, real discovery backend.
