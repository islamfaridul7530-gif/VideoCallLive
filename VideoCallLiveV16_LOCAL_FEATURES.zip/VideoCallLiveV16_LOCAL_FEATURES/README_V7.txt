Video Call Live V7 CORE FORCE FIX
Repeated V6 crash: NoSuchMethodError for ContextCompat.registerReceiver(..., int).
V7 explicitly includes and forces androidx.core:core:1.15.0 in Gradle.
Internal project folder: VideoCallLiveV7_CORE_FORCE_FIX
GitHub Actions must build this V7 folder, not V3/V6.
