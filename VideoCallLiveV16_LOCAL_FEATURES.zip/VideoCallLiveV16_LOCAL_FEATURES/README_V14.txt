Video Call Live V14
- My Photos now has explicit Save Photos and confirmation.
- Female profile setup fills the whole screen with dark background.
- Home Meet New People banner includes a built-in illustrated female figure on the right.
- Coins page uses a pink/purple premium gradient theme.
- Existing V13 female profile flow is retained.
