V13 changes:
- Female selection creates/edits a normal 18+ profile first.
- Creator application remains separate from the normal female ID.
- Edit Profile works and saved details remain in My Profile.
- My Photos opens Android gallery, saves up to 6 persistent photo URIs, and supports remove.
- Following, Notifications, Privacy & Safety, Blocked Users, Help & Support and Settings now open functional screens/local controls instead of dead buttons.
- Home Video Call Live header gets extra top padding so it is below the status bar.
- Creator approval, live following/blocked lists, cloud photo upload and real-time backend behavior still require backend implementation.
