Video Call Live V3 Diagnostic
- Based on the user's V2 source.
- Adds a global uncaught-exception catcher.
- On the next launch after a crash, MainActivity displays the exact Java stack trace.
- MainActivity also catches startup UI/Firebase button exceptions and displays them immediately.
- google-services.json is intentionally NOT included; GitHub workflow should continue copying the user's root google-services.json into app/google-services.json before build.
