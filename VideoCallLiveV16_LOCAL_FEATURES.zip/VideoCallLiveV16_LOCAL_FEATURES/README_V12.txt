Video Call Live V12 - Female Profile Flow
- Female selection now opens a normal 18+ profile setup, not Creator setup.
- Normal female profile stores name, age, country and bio.
- My Profile displays normal female details.
- Separate Become a Creator entry added.
- Quick Login cannot directly apply as creator; phone verification is requested.
- Creator application uses Pending status; paid creator access is not automatically granted.
- Free-form creator call-rate selection removed from the normal female flow.
- Home header top padding increased.
- Photo picker, real approval backend, real video calling, billing and payout remain future/backend work.
