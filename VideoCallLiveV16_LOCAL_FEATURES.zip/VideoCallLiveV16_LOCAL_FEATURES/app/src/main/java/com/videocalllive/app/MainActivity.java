package com.videocalllive.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        android.content.SharedPreferences cp = getSharedPreferences("vcl_crash", 0);
        String last = cp.getString("last_crash", null);
        String otpErr = cp.getString("last_otp_error", null);
        String stage = cp.getString("last_stage", null);
        if (last != null || otpErr != null) {
            showCrash((last != null ? last : otpErr) + (stage != null ? "\n\nLAST OTP STAGE: " + stage : ""));
            return;
        }

        try {
            // V8: keep the user signed in when the app is removed from Recent Apps.
            if (FirebaseHelper.ready(this) && FirebaseAuth.getInstance().getCurrentUser() != null) {
                String gender = getSharedPreferences("vcl",0).getString("gender", "");
                Intent next;
                if ("male".equals(gender)) next = new Intent(this, HomeActivity.class);
                else if ("female".equals(gender)) next = new Intent(this, HomeActivity.class);
                else next = new Intent(this, GenderActivity.class);
                startActivity(next);
                finish();
                return;
            }

            LinearLayout r = Ui.root(this);
            r.addView(Ui.title(this, "Video Call Live"));
            r.addView(Ui.body(this, "V12 Profile Flow • Firebase login ready\nMeet people, chat and start live video calls."));

            Button q = Ui.button(this, "Quick Login");
            Button l = Ui.secondary(this, "Login with Phone Number");
            r.addView(q);
            r.addView(l);

            q.setOnClickListener(v -> {
                try {
                    if (!FirebaseHelper.ready(this)) {
                        Ui.toast(this, "Firebase config/initialization failed");
                        return;
                    }
                    FirebaseAuth.getInstance().signInAnonymously()
                        .addOnSuccessListener(x -> {
                            getSharedPreferences("vcl",0).edit().putBoolean("quick",true).apply();
                            startActivity(new Intent(this, GenderActivity.class));
                        })
                        .addOnFailureListener(e -> Ui.toast(this, "Quick Login failed: " + e.getMessage()));
                } catch (Throwable e) {
                    saveAndShow(e);
                }
            });

            l.setOnClickListener(v -> {
                try { startActivity(new Intent(this, LoginActivity.class)); }
                catch (Throwable e) { saveAndShow(e); }
            });

            setContentView(r);
        } catch (Throwable e) {
            saveAndShow(e);
        }
    }

    private void saveAndShow(Throwable e) {
        java.io.StringWriter sw = new java.io.StringWriter();
        e.printStackTrace(new java.io.PrintWriter(sw));
        String s = sw.toString();
        getSharedPreferences("vcl_crash",0).edit().putString("last_crash",s).apply();
        showCrash(s);
    }

    private void showCrash(String crash) {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32,32,32,32);

        TextView title = new TextView(this);
        title.setText("Video Call Live - Crash Error");
        title.setTextSize(22);
        title.setTextColor(Color.RED);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nScreenshot this screen or copy the error below:\n\n" + crash);
        info.setTextSize(13);
        info.setTextIsSelectable(true);
        box.addView(info);

        Button copy = new Button(this);
        copy.setText("Copy Error");
        copy.setOnClickListener(v -> {
            ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
                .setPrimaryClip(android.content.ClipData.newPlainText("crash", crash));
            Toast.makeText(this, "Error copied", Toast.LENGTH_SHORT).show();
        });
        box.addView(copy);

        Button clear = new Button(this);
        clear.setText("Clear Error & Try App");
        clear.setOnClickListener(v -> {
            getSharedPreferences("vcl_crash",0).edit().clear().apply();
            recreate();
        });
        box.addView(clear);

        sv.addView(box);
        setContentView(sv);
    }
}
