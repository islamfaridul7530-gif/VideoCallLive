package com.videocalllive.app;
import android.content.*;import android.graphics.*;import android.view.*;
public class HeroGirlView extends View{
 Paint p=new Paint(1); public HeroGirlView(Context c){super(c);}
 protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setColor(Color.rgb(255,205,185));c.drawCircle(w*.55f,h*.29f,w*.18f,p);p.setColor(Color.rgb(50,25,55));c.drawArc(w*.35f,h*.08f,w*.76f,h*.50f,185,190,true,p);p.setColor(Color.rgb(255,205,185));c.drawCircle(w*.49f,h*.30f,w*.15f,p);p.setColor(Color.rgb(40,22,48));c.drawCircle(w*.44f,h*.28f,4,p);c.drawCircle(w*.55f,h*.28f,4,p);p.setColor(Color.rgb(185,70,95));c.drawArc(w*.45f,h*.32f,w*.57f,h*.39f,10,160,false,p);p.setColor(Color.rgb(255,115,165));Path body=new Path();body.moveTo(w*.24f,h);body.quadTo(w*.30f,h*.52f,w*.50f,h*.48f);body.quadTo(w*.78f,h*.50f,w*.88f,h);body.close();c.drawPath(body,p);p.setColor(Color.argb(70,255,255,255));c.drawCircle(w*.80f,h*.22f,w*.08f,p);c.drawCircle(w*.25f,h*.55f,w*.05f,p);}
}
