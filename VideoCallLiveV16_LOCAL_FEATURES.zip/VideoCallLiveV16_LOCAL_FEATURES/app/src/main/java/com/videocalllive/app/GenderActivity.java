package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class GenderActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Select your gender"));r.addView(Ui.body(this,"Choose how you want to use Video Call Live."));Button m=Ui.button(this,"Male"),f=Ui.secondary(this,"Female");r.addView(m);r.addView(f);m.setOnClickListener(v->go("male"));f.setOnClickListener(v->go("female"));setContentView(r);}
 void go(String g){android.content.SharedPreferences p=getSharedPreferences("vcl",0);p.edit().putString("gender",g).putInt("free_calls_left",3).apply();FirebaseHelper.saveProfile(this,g);if(g.equals("female")){startActivity(new Intent(this,FemaleProfileSetupActivity.class));}else{startActivity(new Intent(this,HomeActivity.class));}finishAffinity();}
}