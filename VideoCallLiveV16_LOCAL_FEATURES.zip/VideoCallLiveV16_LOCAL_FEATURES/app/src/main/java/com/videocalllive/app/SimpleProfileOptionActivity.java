package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class SimpleProfileOptionActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);String type=getIntent().getStringExtra("type");if(type==null)type="Settings";LinearLayout r=Ui.root(this);r.setPadding(Ui.dp(this,14),Ui.dp(this,42),Ui.dp(this,14),Ui.dp(this,10));r.addView(Ui.backTitle(this,type));android.content.SharedPreferences p=getSharedPreferences("vcl",0);
 if(type.equals("Following")){StringBuilder z=new StringBuilder();for(String q:new String[]{"Priya","Anjali","Sara","Neha","Aisha","Maya"})if(p.getBoolean("follow_"+q,false))z.append("♥  ").append(q).append("\n\n");r.addView(Ui.body(this,z.length()==0?"No followed profiles yet.":z.toString()));}
 else if(type.equals("Notifications")){Switch s=new Switch(this);s.setText("Enable notifications");s.setTextColor(android.graphics.Color.WHITE);s.setChecked(p.getBoolean("notifications",true));s.setOnCheckedChangeListener((b1,on)->p.edit().putBoolean("notifications",on).apply());r.addView(s);}
 else if(type.equals("Privacy & Safety")){r.addView(Ui.body(this,"Safety controls for your account."));Switch s=new Switch(this);s.setText("Allow messages from people I don't follow");s.setTextColor(android.graphics.Color.WHITE);s.setChecked(p.getBoolean("allow_messages",true));s.setOnCheckedChangeListener((b1,on)->p.edit().putBoolean("allow_messages",on).apply());r.addView(s);}
 else if(type.equals("Blocked Users")){StringBuilder z=new StringBuilder();for(String q:new String[]{"Priya","Anjali","Sara","Neha","Aisha","Maya"})if(p.getBoolean("block_"+q,false))z.append("🚫  ").append(q).append("\n\n");r.addView(Ui.body(this,z.length()==0?"No blocked users.":z.toString()));}
 else if(type.equals("Help & Support")){r.addView(Ui.body(this,"Need help?\n\n• Report abusive profiles from their profile/call screen.\n• Never share OTP or payment passwords.\n• Video Call Live is for adults 18+."));}
 else {r.addView(Ui.body(this,"Account settings"));Switch s=new Switch(this);s.setText("Show online status");s.setTextColor(android.graphics.Color.WHITE);s.setChecked(p.getBoolean("online_status",true));s.setOnCheckedChangeListener((b1,on)->p.edit().putBoolean("online_status",on).apply());r.addView(s);}
 setContentView(r);}
}
