package com.videocalllive.app;

import android.app.Application;
import android.content.SharedPreferences;
import java.io.PrintWriter;
import java.io.StringWriter;

public class CrashApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                getSharedPreferences("vcl_crash", MODE_PRIVATE)
                    .edit().putString("last_crash", sw.toString()).commit();
            } catch (Throwable ignored) {}
            if (old != null) old.uncaughtException(thread, error);
        });
    }
}
