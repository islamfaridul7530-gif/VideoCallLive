package com.videocalllive.app;

import android.app.Application;
import android.app.Activity;
import android.os.Bundle;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;
import android.content.SharedPreferences;
import java.io.PrintWriter;
import java.io.StringWriter;

public class CrashApplication extends Application {
 private Activity visible; private ListenerRegistration calls; private String watching; private final Set<String> alerted=new HashSet<>();
 private void monitor(){String uid=FirebaseAuth.getInstance().getUid();if(uid==null||visible==null)return;if(uid.equals(watching)&&calls!=null)return;if(calls!=null)calls.remove();watching=uid;calls=FirebaseFirestore.getInstance().collection("calls").whereEqualTo("receiverId",uid).whereEqualTo("status","ringing").addSnapshotListener((q,e)->{if(q==null||visible==null||visible.isFinishing()||visible instanceof RealCallActivity)return;for(DocumentChange c:q.getDocumentChanges()){DocumentSnapshot d=c.getDocument();if(c.getType()!=DocumentChange.Type.ADDED||!alerted.add(d.getId()))continue;Long created=d.getLong("createdAt");if(created!=null&&System.currentTimeMillis()-created>60000)continue;Activity a=visible;a.runOnUiThread(()->{if(visible!=null&&!visible.isFinishing()&&!(visible instanceof RealCallActivity))IncomingCallDialog.show(visible,d.getId(),d.getString("callerId"),d.getString("callerName"));});}});}

    @Override public void onCreate() {
        super.onCreate();
 registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks(){public void onActivityCreated(Activity a,Bundle b){}public void onActivityStarted(Activity a){}public void onActivityResumed(Activity a){visible=a;monitor();}public void onActivityPaused(Activity a){if(visible==a)visible=null;}public void onActivityStopped(Activity a){}public void onActivitySaveInstanceState(Activity a,Bundle b){}public void onActivityDestroyed(Activity a){if(visible==a)visible=null;}});
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                getSharedPreferences("vcl_crash", MODE_PRIVATE)
                    .edit().putString("last_crash", sw.toString()).commit();
            } catch (Throwable ignored) {}
            if (old != null) old.uncaughtException(thread, error);
        });
    }
}
