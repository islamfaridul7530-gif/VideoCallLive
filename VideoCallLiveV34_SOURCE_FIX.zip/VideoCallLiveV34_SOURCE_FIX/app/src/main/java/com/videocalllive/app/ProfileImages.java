package com.videocalllive.app;
import android.app.Activity;import android.graphics.*;import android.widget.*;import android.view.*;import java.net.*;import java.io.*;
public class ProfileImages{
 public static void load(ImageView target,String url,String name){
  if(url==null||!url.startsWith("https://"))return;
  new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(9000);c.setReadTimeout(9000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)target.post(()->target.setImageBitmap(b));}finally{c.disconnect();}}catch(Exception ignored){}}).start();
 }
 public static ImageView avatar(Activity a,String url,String name){ImageView v=new ImageView(a);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(Ui.bg(0xff73379b,Ui.dp(a,16)));v.setLayoutParams(new LinearLayout.LayoutParams(-1,Ui.dp(a,155)));if(url!=null&&url.startsWith("https://")){new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(9000);c.setReadTimeout(9000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)a.runOnUiThread(()->{if(!a.isFinishing())v.setImageBitmap(b);});}finally{c.disconnect();}}catch(Exception ignored){}}).start();}else{Bitmap b=Bitmap.createBitmap(160,160,Bitmap.Config.ARGB_8888);Canvas cv=new Canvas(b);cv.drawColor(0xff73379b);Paint p=new Paint(3);p.setColor(-1);p.setTextSize(70);p.setTextAlign(Paint.Align.CENTER);cv.drawText(name==null||name.isEmpty()?"?":name.substring(0,1).toUpperCase(),80,105,p);v.setImageBitmap(b);}return v;}
}
