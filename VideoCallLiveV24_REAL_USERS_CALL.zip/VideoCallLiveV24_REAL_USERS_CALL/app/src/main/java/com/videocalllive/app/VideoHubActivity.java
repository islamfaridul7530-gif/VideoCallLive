package com.videocalllive.app;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;
public class VideoHubActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Ui.root(this);r.addView(Ui.title(this,"Video Calls"));r.addView(Ui.body(this,"V24 live call test: sign in on two phones with separate accounts, then open Real Users on both."));Button real=Ui.button(this,"🎥 REAL VIDEO CALL • V24");r.addView(real);real.setOnClickListener(v->startActivity(new Intent(this,RealUsersActivity.class)));LinearLayout nav=Ui.nav(this,"Video");for(int i=0;i<nav.getChildCount();i++){final int k=i;nav.getChildAt(i).setOnClickListener(v->{if(k==0)startActivity(new Intent(this,HomeActivity.class));if(k==1)startActivity(new Intent(this,MessagesActivity.class));if(k==3)startActivity(new Intent(this,TopUpActivity.class));if(k==4)startActivity(new Intent(this,MyProfileActivity.class));});}r.addView(nav);setContentView(r);}
}
